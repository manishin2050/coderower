from django.shortcuts import render,redirect,HttpResponse

# create your views here
def home_page(request):
    return HttpResponse('this is homepage and this is very good place to read this ')